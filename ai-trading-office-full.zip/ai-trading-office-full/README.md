# AI Trading Office — Full Paper-Trading Build

A runnable six-department / 33-role stock research and **paper trading** application. It starts with simulated market data so it works without paid keys, and includes adapters for Alpaca market data/paper orders and OpenAI structured agent opinions.

## Included
- 6 departments / 33 visual roles
- 20-symbol liquid-stock/ETF starter universe
- 15-minute simulated or Alpaca bars
- EMA, RSI, ATR, relative volume, momentum, breakout scanner
- Bull / Bear / Devil's Advocate committee
- Strategy decision with NO_TRADE support
- Deterministic risk sizing, max position cap and minimum R:R gate
- Simulated execution or Alpaca paper-order adapter
- SQLite journal (easy zero-config default)
- Scan, analysis, risk, paper-order, journal and baseline-backtest APIs
- Next.js dashboard
- Docker Compose

## Start
```bash
cp .env.example .env
docker compose up --build
```
Dashboard: http://localhost:3000
API docs: http://localhost:8000/docs

## Zero-key mode
Leave `USE_REAL_DATA=false`, `USE_OPENAI=false`, `USE_ALPACA_PAPER=false`. The full pipeline runs locally with deterministic simulated market data and simulated fills.

## Enable real paper infrastructure
Add your own credentials to `.env`, then enable the relevant flags. **Do not use live brokerage credentials.** The broker adapter rejects any base URL that is not Alpaca's paper API.

## Important
This is research/software infrastructure, not a promise of profitability. Paper fills do not reproduce all live-market effects. Validate with historical tests and forward paper trading before considering any real-money workflow.
