from .config import settings
def size(equity,entry,stop):
    risk_dollars=equity*settings.risk_per_trade; per=abs(entry-stop)
    if per<=0:return {'approved':False,'reason':'invalid stop','qty':0}
    by_risk=int(risk_dollars/per); by_notional=int((equity*settings.max_position_pct)/entry); q=max(0,min(by_risk,by_notional))
    return {'approved':q>0,'qty':q,'risk_dollars':round(q*per,2),'max_risk_dollars':round(risk_dollars,2),'notional':round(q*entry,2)}
def gate(direction,entry,stop,target,equity):
    rr=abs(target-entry)/(abs(entry-stop)+1e-9); s=size(equity,entry,stop); reasons=[]
    if direction=='NO_TRADE': reasons.append('strategy selected NO TRADE')
    if rr<settings.min_rr: reasons.append(f'R:R {rr:.2f} below minimum {settings.min_rr}')
    if not s['approved']: reasons.append(s.get('reason','position size rejected'))
    return {'approved':not reasons,'rr':round(rr,2),'position':s,'reasons':reasons}
