from fastapi import FastAPI,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .orchestrator import scan,analyze
from .risk import size
from .models import SessionLocal,Decision,Trade
from .broker import submit
from .config import settings
app=FastAPI(title='AI Trading Office',version='2.0.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
TEAMS=[('Market Scanner',5),('Technical Analysis',7),('Market Intelligence',5),('Strategy Committee',5),('Risk Management',5),('Execution & Review',6)]
@app.get('/health')
def health():return {'ok':True,'mode':settings.app_mode,'real_data':settings.use_real_data,'openai':settings.use_openai,'alpaca_paper':settings.use_alpaca_paper}
@app.get('/api/teams')
def teams():return [{'name':n,'roles':c} for n,c in TEAMS]
@app.get('/api/scan')
async def do_scan(limit:int=10):return await scan(min(max(limit,1),20))
@app.get('/api/analyze/{symbol}')
async def do_analyze(symbol:str):
    a=await analyze(symbol.upper()); s=a['strategy'];
    with SessionLocal() as db:
        db.add(Decision(symbol=a['symbol'],direction=s['direction'],score=s['score'],entry=s['entry'],stop=s['stop'],target=s['target'],status=a['final_status'],rationale=str(a['agents'])));db.commit()
    return a
class RiskReq(BaseModel):equity:float;entry:float;stop:float
@app.post('/api/risk/size')
def risk(req:RiskReq):return size(req.equity,req.entry,req.stop)
@app.post('/api/paper-trade/{symbol}')
async def paper_trade(symbol:str):
    a=await analyze(symbol.upper());
    if not a['risk']['approved']:raise HTTPException(400,detail={'message':'Risk rejected trade','analysis':a})
    s=a['strategy']; qty=a['risk']['position']['qty']; side='buy' if s['direction']=='LONG' else 'sell'; order=await submit(a['symbol'],side,qty)
    with SessionLocal() as db: db.add(Trade(symbol=a['symbol'],side=side,qty=qty,entry=s['entry'],stop=s['stop'],target=s['target']));db.commit()
    return {'analysis':a,'order':order}
@app.get('/api/journal')
def journal():
    with SessionLocal() as db:
        ds=db.query(Decision).order_by(Decision.id.desc()).limit(100).all(); ts=db.query(Trade).order_by(Trade.id.desc()).limit(100).all()
        return {'decisions':[{'id':x.id,'symbol':x.symbol,'direction':x.direction,'score':x.score,'status':x.status,'entry':x.entry,'stop':x.stop,'target':x.target,'created_at':x.created_at} for x in ds],'trades':[{'id':x.id,'symbol':x.symbol,'side':x.side,'qty':x.qty,'entry':x.entry,'status':x.status,'pnl':x.pnl,'created_at':x.created_at} for x in ts]}
@app.get('/api/backtest/{symbol}')
async def backtest(symbol:str):
    from .market import bars
    bs=await bars(symbol.upper(),120); cs=[x['c'] for x in bs]; rets=[cs[i]/cs[i-1]-1 for i in range(1,len(cs))]; total=(cs[-1]/cs[0]-1)*100; win=sum(r>0 for r in rets)/len(rets)*100
    return {'symbol':symbol.upper(),'bars':len(bs),'buy_hold_return_pct':round(total,2),'positive_bar_pct':round(win,1),'note':'Baseline diagnostic, not proof of strategy edge.'}
