from .market import bars,metrics,UNIVERSE
from .agents import opinion
from .risk import gate
from .config import settings
async def scan(limit=10):
    out=[]
    for s in UNIVERSE:
        m=metrics(await bars(s)); out.append({'symbol':s,**m})
    return sorted(out,key=lambda x:x['scanner_score'],reverse=True)[:limit]
async def analyze(symbol):
    m=metrics(await bars(symbol)); bull=await opinion('bull',symbol,m); bear=await opinion('bear',symbol,m); devil=await opinion('devil',symbol,m)
    edge=bull.score-bear.score; direction='LONG' if edge>=15 and m['scanner_score']>=55 else ('SHORT' if edge<=-15 and m['scanner_score']>=55 else 'NO_TRADE')
    p=m['price']; atr=max(m['atr14'],p*.005)
    if direction=='SHORT': entry=p; stop=p+1.2*atr; target=p-2.4*atr
    else: entry=p; stop=p-1.2*atr; target=p+2.4*atr
    g=gate(direction,entry,stop,target,settings.account_equity)
    return {'symbol':symbol,'metrics':m,'agents':{'bull':bull.model_dump(),'bear':bear.model_dump(),'devil':devil.model_dump()},'strategy':{'direction':direction,'score':round((bull.score+(100-bear.score)+m['scanner_score'])/3,1),'entry':round(entry,2),'stop':round(stop,2),'target':round(target,2)},'risk':g,'final_status':'APPROVED' if g['approved'] else 'REJECTED'}
