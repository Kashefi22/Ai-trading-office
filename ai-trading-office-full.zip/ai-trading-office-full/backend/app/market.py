import math,random
from datetime import datetime,timedelta,timezone
import httpx
from .config import settings
UNIVERSE=['AAPL','MSFT','NVDA','AMZN','META','GOOGL','TSLA','AMD','AVGO','NFLX','JPM','V','MA','COST','LLY','SPY','QQQ','IWM','XLF','SMH']
def simulated_bars(symbol,n=120):
    rng=random.Random(sum(map(ord,symbol))); p=80+rng.random()*320; out=[]
    for i in range(n):
        drift=(rng.random()-.47)*.012; o=p; c=max(2,p*(1+drift)); h=max(o,c)*(1+rng.random()*.006); l=min(o,c)*(1-rng.random()*.006); v=int(500000+rng.random()*4000000); p=c
        out.append({'t':(datetime.now(timezone.utc)-timedelta(minutes=15*(n-i))).isoformat(),'o':o,'h':h,'l':l,'c':c,'v':v})
    return out
async def bars(symbol,n=120):
    if not settings.use_real_data or not settings.alpaca_api_key:return simulated_bars(symbol,n)
    headers={'APCA-API-KEY-ID':settings.alpaca_api_key,'APCA-API-SECRET-KEY':settings.alpaca_secret_key}
    params={'timeframe':'15Min','limit':n,'adjustment':'raw','feed':'iex'}
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.get(f'{settings.alpaca_data_base_url}/v2/stocks/{symbol}/bars',headers=headers,params=params); r.raise_for_status(); return r.json().get('bars',[])
def metrics(bs):
    cs=[x['c'] for x in bs]; vs=[x['v'] for x in bs]; p=cs[-1]
    ema=lambda span: _ema(cs,span)
    gains=[max(0,cs[i]-cs[i-1]) for i in range(1,len(cs))][-14:]; losses=[max(0,cs[i-1]-cs[i]) for i in range(1,len(cs))][-14:]; rs=(sum(gains)/14)/(sum(losses)/14+1e-9); rsi=100-100/(1+rs)
    trs=[max(x['h']-x['l'],abs(x['h']-bs[i-1]['c']),abs(x['l']-bs[i-1]['c'])) for i,x in enumerate(bs) if i>0][-14:]; atr=sum(trs)/len(trs)
    rv=vs[-1]/(sum(vs[-21:-1])/20+1); high20=max(x['h'] for x in bs[-20:-1]); low20=min(x['l'] for x in bs[-20:-1])
    trend=(p/ema(50)-1)*100; breakout=(p/high20-1)*100; mom=(p/cs[-10]-1)*100
    score=max(0,min(100,50+trend*8+mom*5+(rv-1)*15+breakout*8))
    return {'price':round(p,2),'ema9':round(ema(9),2),'ema20':round(ema(20),2),'ema50':round(ema(50),2),'rsi14':round(rsi,1),'atr14':round(atr,2),'relative_volume':round(rv,2),'high20':round(high20,2),'low20':round(low20,2),'trend_pct':round(trend,2),'momentum_pct':round(mom,2),'scanner_score':round(score,1)}
def _ema(a,span):
    k=2/(span+1); e=a[0]
    for x in a[1:]:e=x*k+e*(1-k)
    return e
