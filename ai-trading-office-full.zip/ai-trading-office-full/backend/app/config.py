from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_mode:str='paper'; database_url:str='sqlite:///./trading_office.db'; openai_api_key:str=''
    openai_model:str='gpt-5.6'; alpaca_api_key:str=''; alpaca_secret_key:str=''
    alpaca_paper_base_url:str='https://paper-api.alpaca.markets'; alpaca_data_base_url:str='https://data.alpaca.markets'
    use_real_data:bool=False; use_openai:bool=False; use_alpaca_paper:bool=False
    account_equity:float=25000; risk_per_trade:float=.005; max_daily_loss_pct:float=.02; max_position_pct:float=.10; min_rr:float=1.8
    model_config=SettingsConfigDict(env_file='.env',extra='ignore')
settings=Settings()
