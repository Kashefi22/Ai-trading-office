import httpx
from .config import settings
async def submit(symbol,side,qty):
    if not settings.use_alpaca_paper:return {'id':f'sim-{symbol}','symbol':symbol,'side':side,'qty':qty,'status':'filled-simulated'}
    if not settings.alpaca_paper_base_url.startswith('https://paper-api.alpaca.markets'): raise RuntimeError('Paper safety boundary violated')
    h={'APCA-API-KEY-ID':settings.alpaca_api_key,'APCA-API-SECRET-KEY':settings.alpaca_secret_key}
    payload={'symbol':symbol,'qty':str(qty),'side':side,'type':'market','time_in_force':'day'}
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.post(settings.alpaca_paper_base_url+'/v2/orders',headers=h,json=payload); r.raise_for_status(); return r.json()
