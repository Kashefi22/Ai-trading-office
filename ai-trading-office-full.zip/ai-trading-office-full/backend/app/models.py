from sqlalchemy import create_engine,String,Float,Integer,DateTime,Text
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker
from datetime import datetime,timezone
from .config import settings
class Base(DeclarativeBase): pass
class Decision(Base):
    __tablename__='decisions'; id:Mapped[int]=mapped_column(primary_key=True); symbol:Mapped[str]=mapped_column(String(12),index=True); direction:Mapped[str]=mapped_column(String(12)); score:Mapped[float]=mapped_column(Float); entry:Mapped[float]=mapped_column(Float); stop:Mapped[float]=mapped_column(Float); target:Mapped[float]=mapped_column(Float); status:Mapped[str]=mapped_column(String(24)); rationale:Mapped[str]=mapped_column(Text); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class Trade(Base):
    __tablename__='trades'; id:Mapped[int]=mapped_column(primary_key=True); symbol:Mapped[str]=mapped_column(String(12),index=True); side:Mapped[str]=mapped_column(String(8)); qty:Mapped[int]=mapped_column(Integer); entry:Mapped[float]=mapped_column(Float); stop:Mapped[float]=mapped_column(Float); target:Mapped[float]=mapped_column(Float); status:Mapped[str]=mapped_column(String(20),default='OPEN'); pnl:Mapped[float]=mapped_column(Float,default=0); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
engine=create_engine(settings.database_url,connect_args={'check_same_thread':False} if settings.database_url.startswith('sqlite') else {})
SessionLocal=sessionmaker(engine,expire_on_commit=False); Base.metadata.create_all(engine)
