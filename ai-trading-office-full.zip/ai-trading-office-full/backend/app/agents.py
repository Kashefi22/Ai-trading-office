from pydantic import BaseModel
from .config import settings
class Opinion(BaseModel): stance:str; score:int; thesis:str; risks:list[str]
def fallback(role,symbol,m):
    bullish=m['price']>m['ema20'] and m['rsi14']<75
    if role=='bull': return Opinion(stance='BULL',score=75 if bullish else 48,thesis=f"{symbol} price/EMA and momentum support the long case.",risks=['Resistance can reject price','Momentum can reverse'])
    if role=='bear': return Opinion(stance='BEAR',score=70 if not bullish else 42,thesis=f"{symbol} has downside/reversal risks that must be respected.",risks=['Failed breakout','Market-wide selloff'])
    return Opinion(stance='CAUTION',score=55,thesis='Challenge both sides; avoid trade when evidence conflicts.',risks=['Regime change','Event risk','Slippage'])
async def opinion(role,symbol,m):
    if not settings.use_openai or not settings.openai_api_key:return fallback(role,symbol,m)
    from openai import AsyncOpenAI
    c=AsyncOpenAI(api_key=settings.openai_api_key)
    prompt=f"Role={role}. Analyze {symbol} using only these supplied metrics: {m}. No guarantees. Return stance, score 0-100, thesis, risks."
    r=await c.responses.parse(model=settings.openai_model,input=[{'role':'system','content':'You are one member of a stock research committee. Be evidence-bound and allow NO TRADE.'},{'role':'user','content':prompt}],text_format=Opinion)
    return r.output_parsed
